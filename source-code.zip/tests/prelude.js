var __now = 1000000;
function __el(tag){return {tag:tag,attrs:{},style:{},dataset:{},textContent:'',value:'50',hidden:false,disabled:false,className:'',classList:{_s:{},add:function(c){this._s[c]=1},remove:function(c){delete this._s[c]},toggle:function(c,f){if(f===undefined){this._s[c]=this._s[c]?undefined:1}else{this._s[c]=f?1:undefined}},contains:function(c){return !!this._s[c]}},append:function(){for(var i=0;i<arguments.length;i++){}},appendChild:function(){return arguments[0]},setAttribute:function(k,v){this.attrs[k]=v},getAttribute:function(k){return this.attrs[k]},getBoundingClientRect:function(){return {left:0,top:0,width:60,height:116}},setPointerCapture:function(){},hasPointerCapture:function(){return false},onclick:null};}
var document = {
  getElementById:function(id){return __byId[id] || (__byId[id]=__el('div'))},
  createElement:function(t){return __el(t)},
  querySelector:function(){return __el('button')},
  querySelectorAll:function(){return []},
  addEventListener:function(){}
};
var __byId = {};
var performance = {now:function(){return __now}};
var navigator = {vibrate:function(){}};
var localStorage = {setItem:function(){}};
var __sent = [];
var fetch = function(url,opt){try{__sent.push(JSON.parse(opt.body))}catch(e){__sent.push({parseError:String(e)})}return {ok:true,status:200}};
var requestAnimationFrame = function(){return 0};
var setInterval = function(){return 0};

"""Run the Phone Toy Remote page JS in a real engine against a stub DOM.

Pulls the page out of the plugin source (the same string the server sends),
executes it in QuickJS, and checks it against a port of the game-side maths.

Run:  python tests/test_page.py [path-to-Ui.cs]     (needs: pip install quickjs)
"""
import json
import math
import pathlib
import re
import sys

import quickjs

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent

CANDIDATES = [
    ROOT / "src" / "Ui.cs",                                  # repo layout
    ROOT / "ModSource" / "PhoneToyRemote" / "Ui.cs",         # working install
]
if len(sys.argv) > 1:
    UI = pathlib.Path(sys.argv[1])
else:
    UI = next((p for p in CANDIDATES if p.exists()), CANDIDATES[0])
if not UI.exists():
    print("cannot find Ui.cs; pass its path as an argument")
    raise SystemExit(2)
print("page source:", UI)

src = UI.read_text(encoding="utf-8")
body = src[src.find("internal const string Html = "):]
raw = body[body.find(chr(34)) + 1:body.rfind(chr(34) + ";")]
out = []
i = 0
while i < len(raw):
    c = raw[i]
    if c == chr(92) and i + 1 < len(raw):
        n = raw[i + 1]
        if n == "n":
            out.append(chr(10)); i += 2; continue
        if n == chr(34):
            out.append(chr(34)); i += 2; continue
        if n == chr(92):
            out.append(chr(92)); i += 2; continue
    out.append(c); i += 1
html = "".join(out)
js = re.search(r"<script>(.*?)</script>", html, re.S).group(1)

ids = sorted(set(re.findall(r"id=([A-Za-z_][A-Za-z0-9_]*)", html)))
prelude = (HERE / "prelude.js").read_text(encoding="utf-8-sig")
prelude += chr(10) + "var __ids = " + json.dumps(ids) + ";" + chr(10)
prelude += "__ids.forEach(function(x){ var e = __el('div'); __byId[x] = e; globalThis[x] = e; });" + chr(10)
driver = (HERE / "driver.js").read_text(encoding="utf-8-sig")
data = json.loads(quickjs.Context().eval(prelude + chr(10) + js + chr(10) + driver))


def cs_pattern(pattern, intensity, elapsed):
    """The envelope as the C# side computes it (Plugin.PatternPercent)."""
    n = max(0, min(100, int(intensity)))
    if pattern == "Pulse":
        return n if (elapsed % 1) < 0.4 else 0
    if pattern == "Wave":
        return int(n * (0.2 + 0.8 * (0.5 + 0.5 * math.sin(elapsed * math.pi * 2.0 / 8.0))))
    if pattern == "Tease":
        t = elapsed % 20.0
        return 0 if t >= 12 else int(n * min(1.0, t / 8.0))
    return n


def cs_piston(percent):
    """ToPistonLevel: four speeds - 1-33 low, 34-66 medium, 67-100 high."""
    if percent <= 0:
        return 0
    if percent >= 34:
        return 2 if percent < 67 else 3
    return 1


failures = []

env_bad = [t for t in data["env"] if abs(int(t[3]) - cs_pattern(t[0], t[1], t[2])) > 1]
print("envelope vs the game's maths : %d samples, %d mismatches" % (len(data["env"]), len(env_bad)))
if env_bad:
    failures.append("envelope")
    for t in env_bad[:5]:
        print("   ", t, "cs=", cs_pattern(t[0], t[1], t[2]))

lvl_bad = [t for t in data["lvl"] if cs_piston(t[0]) != t[1] or t[2] != [0, 33, 50, 100][t[1]]]
print("piston level mapping         : 101 values, %d mismatches" % len(lvl_bad))
if lvl_bad:
    failures.append("levels")
    for t in lvl_bad[:5]:
        print("   ", t)

print()
print("%-45s %-9s %-7s %-6s %-6s %-8s" % ("case", "vibe chip", "piston", "graph", "stroke", "carriage"))
for c in data["cases"]:
    print("%-45s %-9s %-7s %-6s %-6s %-8s" % (c["tag"][:45], c["vibeChip"], c["pistonChip"], c["graphNow"], c["stroke"], str(c["carriage"])[:8]))

cases = {c["tag"]: c for c in data["cases"]}


def want(tag, **checks):
    c = cases.get(tag)
    if c is None:
        failures.append("missing case: " + tag)
        return None
    for k, v in checks.items():
        if c[k] != v:
            failures.append("%s: %s = %r, expected %r" % (tag, k, c[k], v))
    return c


near = lambda a, b, tol=3: abs(a - b) <= tol

want("idle before anything", vibeChip="OFF", pistonChip="OFF", graphNow=0.0, graphDrawn=True, stroke=0)
c = want("A  vibrator only, 50 steady", vibeChip="LOW 50%", pistonChip="OFF", stroke=0)
if c and not near(c["graphNow"], 50):
    failures.append("A: the graph should sit at ~50, got %r" % c["graphNow"])
want("B1 piston only, tease 100 at 10s", vibeChip="OFF", pistonChip="HIGH", stroke=1)
want("B2 piston only, inside the tease gap", pistonChip="OFF", stroke=0)
c = cases.get("B1 piston only, tease 100 at 10s")
if c and not c["graphDrawn"]:
    failures.append("B1: the graph must stay drawn while only the piston runs")
c = want("C1 vibe 80 steady + piston 33 tease at 10s", vibeChip="HIGH 80%", pistonChip="LOW", stroke=1)
if c and not near(c["graphNow"], 80):
    failures.append("C1: the graph should sit at ~80, got %r" % c["graphNow"])
want("C2 vibe 80 steady + piston in its gap", vibeChip="HIGH 80%", pistonChip="OFF", stroke=0)
c = cases.get("D  linked, wave 50")
if c:
    if "sync=true" not in (c["ride"] or ""):
        failures.append("D: the link flag should be sent")
    if "P=on/50%/Wave" not in (c["ride"] or ""):
        failures.append("D: a linked piston takes the vibrator's pattern, got %r" % c["ride"])
    if c["pistonChip"] not in ("LOW", "MED", "HIGH"):
        failures.append("D: linked piston chip should name a real speed")
want("E1 drag the piston rail high", pistonChip="HIGH")
want("E2 drag the piston rail low", pistonChip="LOW")
c = cases.get("F  vibrator off, graph stays drawn flat")
if c and (not c["graphDrawn"] or c["graphNow"] != 0.0):
    failures.append("F: with the vibrator off the graph must stay drawn and flat (got %r)" % c["graphNow"])
want("G  after STOP", vibeChip="OFF", pistonChip="OFF", stroke=0, graphNow=0.0)

print()
if failures:
    print("FAIL:")
    for f in failures:
        print("   -", f)
    raise SystemExit(1)
print("PASS: the page matches the game's maths and every behaviour case")

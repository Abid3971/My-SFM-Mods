// Scenarios the test drives through the shipped page.
// The page runs in QuickJS with prelude.js as a stub DOM; this file only pokes
// it the way a user would and records what it did.
var __out = { env: [], lvl: [], cases: [] };

var P = ['Steady','Pulse','Wave','Tease'], I = [0,20,33,50,67,100], T = [0,0.2,0.4,0.5,1,2,3.7,4,6,8,11.9,12,15,19.9,20,23];
for (var a=0;a<P.length;a++) for (var b=0;b<I.length;b++) for (var c=0;c<T.length;c++) __out.env.push([P[a],I[b],T[c],patternLevel(P[a],I[b],T[c])]);
for (var q=0;q<=100;q++) __out.lvl.push([q, pistonLevelFrom(q), pistonSent(q)]);

function frames(n, ms){ for (var k=0;k<n;k++){ __now += ms; animate(); } }
function last(){ return __sent[__sent.length-1] || null; }
function ride(s){ if(!s) return null; return 'V='+(s.VibratorOn?'on':'off')+'/'+s.VibratorIntensity+'%/'+s.VibratorPattern+' P='+(s.PistonOn?'on':'off')+'/'+s.PistonIntensity+'%/'+s.PistonPattern+' sync='+s.Sync; }
function now(){ return Math.round(vDisp*10)/10; }
function reset(vv, vpat, vo, pv, ppat, po, sy){
  sync=!!sy; v=!!vo; p=!!po; started=true;
  vi.value=String(vv); pi.value=String(pv); vp.value=vpat; pp.value=ppat;
  vibeResetEpoch(); pistonResetEpoch(); pPhase=0; __sent.length=0; send(true);
}
function at(n, ms, tag){
  frames(n, ms);
  __out.cases.push({
    tag: tag,
    vibeChip: bigV.textContent,
    pistonChip: bigP.textContent,
    graphNow: now(),
    graphDrawn: (wave.attrs.points||'').split(' ').length > 2,
    stroke: Number(pstroke.style.opacity),
    carriage: pstick.style.bottom,
    ride: ride(last())
  });
}

at(4, 16, 'idle before anything');
reset(50,'Steady',true,60,'Steady',false,false);  at(40,16,  'A  vibrator only, 50 steady');
reset(60,'Steady',false,100,'Tease',true,false);  at(100,100,'B1 piston only, tease 100 at 10s');
                                                    at(60,100, 'B2 piston only, inside the tease gap');
reset(80,'Steady',true,33,'Tease',true,false);    at(100,100,'C1 vibe 80 steady + piston 33 tease at 10s');
                                                    at(60,100, 'C2 vibe 80 steady + piston in its gap');
reset(50,'Wave',true,50,'Wave',true,true);        at(20,100, 'D  linked, wave 50');
reset(60,'Steady',true,50,'Steady',true,false);
pi.value='90'; sliderChanged('p');                  at(2,16,   'E1 drag the piston rail high');
pi.value='10'; sliderChanged('p');                  at(2,16,   'E2 drag the piston rail low');
v=false; p=false;                                   at(90,16,  'F  vibrator off, graph stays drawn flat');
stopAll();                                          at(4,16,   'G  after STOP');

JSON.stringify(__out);

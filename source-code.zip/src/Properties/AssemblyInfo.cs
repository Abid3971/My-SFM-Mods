using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("PhoneToyRemote")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("4.0.0.0")]
[assembly: AssemblyInformationalVersion("4.0.0")]
[assembly: AssemblyProduct("PhoneToyRemote")]
[assembly: AssemblyTitle("PhoneToyRemote")]
[assembly: AssemblyVersion("4.0.0.0")]

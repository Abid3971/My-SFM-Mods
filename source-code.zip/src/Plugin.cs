using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq.Expressions;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using ExposureUnnoticed2.Master.AdultGoods;
using ExposureUnnoticed2.Object3D.AdultGoods;
using ExposureUnnoticed2.Object3D.Player.Scripts;
using ExposureUnnoticed2.Object3D.Player.Scripts.Costume;
using ExposureUnnoticed2.Scripts.Base;
using ExposureUnnoticed2.Scripts.InGame;
using HarmonyLib;
using Il2CppInterop.Runtime;
using UnityEngine;

namespace PhoneToyRemote;

using DateTime = System.DateTime;
using StringComparison = System.StringComparison;
using Exception = System.Exception;
using IConvertible = System.IConvertible;
using Buffer = System.Buffer;
using Object = UnityEngine.Object;

[BepInPlugin("phone.toy.remote", "Phone Toy Remote", "4.0.0")]
[BepInDependency("SFM_custom_mission_v2", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BasePlugin
{
	internal sealed class RemoteState
	{
		public bool Connected { get; set; }

		public bool VibratorOn { get; set; }

		public int VibratorIntensity { get; set; }

		public string VibratorPattern { get; set; } = "Steady";

		public bool PistonOn { get; set; }

		public int PistonIntensity { get; set; }

		public string PistonPattern { get; set; } = "Steady";

		public bool Sync { get; set; }

		internal RemoteState Clone()
		{
			return new RemoteState
			{
				Connected = Connected,
				VibratorOn = VibratorOn,
				VibratorIntensity = VibratorIntensity,
				VibratorPattern = VibratorPattern,
				PistonOn = PistonOn,
				PistonIntensity = PistonIntensity,
				PistonPattern = PistonPattern,
				Sync = Sync
			};
		}
	}

	internal static class Server
	{
		private const int HeaderLimit = 8192;

		private const int BodyLimit = 1024;

		private const int MaxConnections = 8;

		private const int MaxPerAddress = 4;

		private static readonly object Gate = new object();

		private static TcpListener _listener;

		private static Thread _thread;

		private static volatile bool _running;

		private static string _address = "127.0.0.1";

		private static int _port;

		private static readonly SemaphoreSlim Slots = new SemaphoreSlim(8, 8);

		private static readonly ConcurrentDictionary<string, int> PerAddress = new ConcurrentDictionary<string, int>();

		internal static string Url => "http://" + _address + ":" + _port + "/";

		internal static string Address => _address;

		internal static int Port => _port;

		internal static void Start(string address, int port)
		{
			_address = address;
			_port = port;
			_listener = new TcpListener(IPAddress.Parse(address), port);
			_listener.Start();
			_running = true;
			_thread = new Thread(Loop)
			{
				IsBackground = true,
				Name = "PhoneToyRemote.Web"
			};
			_thread.Start();
		}

		internal static void Shutdown()
		{
			_running = false;
			try
			{
				_listener?.Stop();
			}
			catch (Exception)
			{
			}
		}

		private static void Loop()
		{
			while (_running)
			{
				try
				{
					TcpClient client = _listener.AcceptTcpClient();
					ThreadPool.QueueUserWorkItem(delegate
					{
						Serve(client);
					});
				}
				catch (Exception)
				{
					if (!_running)
					{
						break;
					}
					Thread.Sleep(200);
				}
			}
		}

		private static void Serve(TcpClient client)
		{
			string text = null;
			try
			{
				text = ((!(client.Client.RemoteEndPoint is IPEndPoint iPEndPoint)) ? "" : iPEndPoint.Address.ToString());
			}
			catch (Exception)
			{
			}
			if (string.IsNullOrEmpty(text) || !IsAllowedCaller(text))
			{
				client.Dispose();
				return;
			}
			bool flag = false;
			bool flag2 = false;
			try
			{
				int num = PerAddress.AddOrUpdate(text, 1, (string k, int v) => v + 1);
				flag = true;
				if (num > 4)
				{
					Respond(client, Text(503, "Too many connections from this address."));
					return;
				}
				if (!Slots.Wait(0))
				{
					Respond(client, Text(503, "Too many connections."));
					return;
				}
				flag2 = true;
				client.ReceiveTimeout = 3000;
				client.SendTimeout = 3000;
				Handle(client, text);
			}
			catch (Exception)
			{
			}
			finally
			{
				if (flag)
				{
					PerAddress.AddOrUpdate(text, 0, (string k, int v) => Math.Max(0, v - 1));
				}
				if (flag2)
				{
					Slots.Release();
				}
				client.Dispose();
			}
		}

		private static void Handle(TcpClient client, string address)
		{
			NetworkStream stream = client.GetStream();
			byte[] array = new byte[10240];
			int i = 0;
			int headEnd;
			string text = ReadHead(stream, array, ref i, out headEnd);
			if (text == null)
			{
				Respond(client, Text(431, "Request too large."));
				return;
			}
			int num = text.IndexOf("\r\n", StringComparison.Ordinal);
			string[] array2 = ((num < 0) ? text : text.Substring(0, num)).Split(' ', 3, StringSplitOptions.RemoveEmptyEntries);
			if (array2.Length < 2)
			{
				return;
			}
			string text2 = array2[0];
			string text3 = array2[1];
			Dictionary<string, string> dictionary = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			string[] array3 = text.Substring(0, headEnd).Split('\n');
			foreach (string text4 in array3)
			{
				int num2 = text4.IndexOf(':', StringComparison.Ordinal);
				if (num2 > 0)
				{
					dictionary[text4.Substring(0, num2).Trim()] = text4.Substring(num2 + 1).Trim();
				}
			}
			if (!HostMatches(dictionary))
			{
				Respond(client, Text(403, "Wrong host."));
			}
			else if (text2 == "OPTIONS")
			{
				Respond(client, Text(405, "Not allowed."));
			}
			else if (text2 == "GET" && (text3 == "/" || text3 == "/index.html"))
			{
				if (GateOpen())
				{
					Respond(client, Html(Ui.Html));
				}
				else
				{
					Respond(client, Html("<!doctype html><meta charset=utf-8><body style='font-family:system-ui;background:#202028;color:#f5f3f8;display:grid;place-items:center;height:100vh'><p>Phone Toy Remote is switched off. Turn it on in the game phone's settings.</p>"));
				}
			}
			else if (text3.StartsWith("/api/", StringComparison.Ordinal))
			{
				if (!GateOpen())
				{
					Respond(client, Json(503, "{" + Dq("error") + ":" + Dq("off") + "}"));
					return;
				}
				dictionary.TryGetValue("X-Remote-Key", out var value);
				switch (Pairing.Verify(address, value))
				{
				case 2:
					Respond(client, Json(429, "{" + Dq("error") + ":" + Dq("ignored") + "}"));
					return;
				case 1:
					Respond(client, Json(401, "{" + Dq("error") + ":" + Dq("code") + "}"));
					return;
				}
				if (text2 == "GET" && text3 == "/api/status")
				{
					RemoteState value2;
					lock (Plugin.Gate)
					{
						value2 = _state.Clone();
					}
					Respond(client, Json(200, JsonSerializer.Serialize(value2)));
				}
				else if (text2 == "POST" && (text3 == "/api/control" || text3 == "/api/logout"))
				{
					int result = 0;
					foreach (KeyValuePair<string, string> item in dictionary)
					{
						if (string.Equals(item.Key, "Content-Length", StringComparison.OrdinalIgnoreCase))
						{
							int.TryParse(item.Value, out result);
						}
					}
					if (result > 1024)
					{
						Respond(client, Text(413, "Body too large."));
						return;
					}
					int num3;
					int num4;
					for (num3 = headEnd + 4; i - num3 < result && i < array.Length; i += num4)
					{
						num4 = stream.Read(array, i, array.Length - i);
						if (num4 <= 0)
						{
							break;
						}
					}
					string @string = Encoding.UTF8.GetString(array, num3, Math.Min(result, i - num3));
					RemoteState remoteState;
					try
					{
						remoteState = JsonSerializer.Deserialize<RemoteState>(@string) ?? new RemoteState();
					}
					catch (JsonException)
					{
						remoteState = new RemoteState();
					}
					if (text3 == "/api/logout")
					{
						if (Pairing.Holds(address))
						{
							lock (Plugin.Gate)
							{
								_state = new RemoteState();
								_lastHeartbeatUtc = DateTime.MinValue;
								_vibeStartedUtc = DateTime.MinValue;
								_pistonStartedUtc = DateTime.MinValue;
								_leaseDropped = true;
							}
							Pairing.DropIf(address);
						}
						Respond(client, Json(200, "{" + Dq("ok") + ":true}"));
						return;
					}
					switch (Pairing.Claim(address))
					{
					case 2:
						Respond(client, Json(409, "{" + Dq("error") + ":" + Dq("taken") + "}"));
						return;
					case 0:
						Instance.LogPhone("a phone took the remote.");
						break;
					}
					lock (Plugin.Gate)
					{
						bool flag3 = _vibeStartedUtc == default(DateTime) && _pistonStartedUtc == default(DateTime);
						bool flag4 = !string.Equals(_state.VibratorPattern, remoteState.VibratorPattern, StringComparison.Ordinal) || (!_state.VibratorOn && remoteState.VibratorOn);
						bool flag5 = !string.Equals(_state.PistonPattern, remoteState.PistonPattern, StringComparison.Ordinal) || (!_state.PistonOn && remoteState.PistonOn);
						if (flag3 || flag4)
						{
							_vibeStartedUtc = DateTime.UtcNow;
						}
						if (flag3 || flag5)
						{
							_pistonStartedUtc = DateTime.UtcNow;
						}
						remoteState.Connected = true;
						_state = remoteState;
						_lastHeartbeatUtc = DateTime.UtcNow;
						LogControlState(remoteState);
					}
					Respond(client, Json(200, "{" + Dq("ok") + ":true}"));
				}
				else
				{
					Respond(client, Text(404, "Not found."));
				}
			}
			else
			{
				Respond(client, Text(404, "Not found."));
			}
		}

		private static string ReadHead(NetworkStream stream, byte[] buffer, ref int read, out int headEnd)
		{
			headEnd = -1;
			while (read < buffer.Length)
			{
				string @string = Encoding.UTF8.GetString(buffer, 0, read);
				int num = @string.IndexOf("\r\n\r\n", StringComparison.Ordinal);
				if (num >= 0)
				{
					headEnd = num;
					return @string;
				}
				if (read >= 8192)
				{
					return null;
				}
				int num2 = stream.Read(buffer, read, buffer.Length - read);
				if (num2 <= 0)
				{
					break;
				}
				read += num2;
			}
			string string2 = Encoding.UTF8.GetString(buffer, 0, read);
			int num3 = string2.IndexOf("\r\n\r\n", StringComparison.Ordinal);
			if (num3 < 0)
			{
				return null;
			}
			headEnd = num3;
			return string2;
		}

		private static bool HostMatches(Dictionary<string, string> headers)
		{
			if (!headers.TryGetValue("Host", out var value) || string.IsNullOrEmpty(value))
			{
				return false;
			}
			if (!AuthorityMatches(value))
			{
				return false;
			}
			if (headers.TryGetValue("Origin", out var value2) && !string.IsNullOrEmpty(value2))
			{
				if (!value2.StartsWith("http://", StringComparison.OrdinalIgnoreCase))
				{
					return false;
				}
				if (!AuthorityMatches(value2.Substring(7)))
				{
					return false;
				}
			}
			return true;
		}

		private static bool AuthorityMatches(string authority)
		{
			if (string.IsNullOrEmpty(authority))
			{
				return false;
			}
			string a = authority.Trim();
			if (string.Equals(a, _address + ":" + _port, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
			if (string.Equals(_address, "127.0.0.1", StringComparison.Ordinal) && string.Equals(a, "localhost:" + _port, StringComparison.OrdinalIgnoreCase))
			{
				return true;
			}
			return false;
		}

		private static void Respond(TcpClient client, byte[] payload)
		{
			try
			{
				NetworkStream stream = client.GetStream();
				stream.Write(payload, 0, payload.Length);
				stream.Flush();
			}
			catch (Exception)
			{
			}
		}

		private static byte[] Text(int status, string body)
		{
			return Build(status, "text/plain; charset=utf-8", Encoding.UTF8.GetBytes(body));
		}

		private static byte[] Json(int status, string body)
		{
			return Build(status, "application/json; charset=utf-8", Encoding.UTF8.GetBytes(body));
		}

		private static byte[] Html(string body)
		{
			return Build(200, "text/html; charset=utf-8", Encoding.UTF8.GetBytes(body));
		}

		private static byte[] Build(int status, string type, byte[] body)
		{
			string s = "HTTP/1.1 " + status + " " + Reason(status) + "\r\nContent-Type: " + type + "\r\nContent-Length: " + body.Length + "\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nX-Frame-Options: DENY\r\nCross-Origin-Resource-Policy: same-origin\r\nCross-Origin-Opener-Policy: same-origin\r\nPermissions-Policy: camera=(), microphone=(), geolocation=()\r\nContent-Security-Policy: default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'\r\n\r\n";
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			byte[] array = new byte[bytes.Length + body.Length];
			Buffer.BlockCopy(bytes, 0, array, 0, bytes.Length);
			Buffer.BlockCopy(body, 0, array, bytes.Length, body.Length);
			return array;
		}

		private static string Reason(int status)
		{
			return status switch
			{
				200 => "OK", 
				401 => "Unauthorized", 
				403 => "Forbidden", 
				404 => "Not Found", 
				405 => "Method Not Allowed", 
				409 => "Conflict", 
				413 => "Payload Too Large", 
				429 => "Too Many Requests", 
				431 => "Request Header Fields Too Large", 
				503 => "Service Unavailable", 
				_ => "Status", 
			};
		}

		private static string Dq(string text)
		{
			return "\"" + text + "\"";
		}
	}

	internal static class Pairing
	{
		private sealed class Record
		{
			public int Wrong;

			public long LastWrong;

			public long IgnoredUntil;
		}

		internal sealed class Controller
		{
			public string Address;

			public long LastBeat;
		}

		private const string Alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

		private const int CodeLength = 12;

		private const int MaxWrong = 5;

		private const long IgnoreMillis = 60000L;

		private const int MaxRecords = 256;

		private static readonly object Gate = new object();

		private static string _code = "";

		private static byte[] _codeBytes = new byte[0];

		private static Controller _controller;

		private static readonly Dictionary<string, Record> _records = new Dictionary<string, Record>();

		private static long Now => Environment.TickCount64;

		internal static string Display
		{
			get
			{
				lock (Gate)
				{
					return _code;
				}
			}
		}

		internal static string Holder
		{
			get
			{
				lock (Gate)
				{
					return (_controller == null) ? null : _controller.Address;
				}
			}
		}

		internal static void NewCode()
		{
			lock (Gate)
			{
				byte[] array = new byte[12];
				using (RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create())
				{
					randomNumberGenerator.GetBytes(array);
				}
				StringBuilder stringBuilder = new StringBuilder(12);
				for (int i = 0; i < 12; i++)
				{
					stringBuilder.Append("0123456789ABCDEFGHJKMNPQRSTVWXYZ"[array[i] % "0123456789ABCDEFGHJKMNPQRSTVWXYZ".Length]);
				}
				_code = stringBuilder.ToString();
				_codeBytes = Encoding.ASCII.GetBytes(_code);
			}
		}

		internal static int Verify(string address, string key)
		{
			// PAIRING HARDENING (v2.0.2): the code that reaches the server
			// is compared after normalisation - chat-wrapped line breaks,
			// copied spaces, a stray dash, lowercase letters, and the
			// lookalike letters the alphabet avoids (O->0, I/L->1) no
			// longer turn the right code into "Wrong code". What matters
			// is the characters, not how they travelled.
			string text = NormalizeKey(key);
			if (string.IsNullOrEmpty(text))
			{
				return 1;
			}
			lock (Gate)
			{
				Record record = RecordFor(address);
				long now = Now;
				if (record.IgnoredUntil > now)
				{
					return 2;
				}
				bool flag = text.Length == _code.Length;
				if (flag)
				{
					flag = CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(text), _codeBytes);
				}
				if (flag)
				{
					record.Wrong = 0;
					return 0;
				}
				record.Wrong++;
				record.LastWrong = now;
				if (record.Wrong >= 5)
				{
					record.IgnoredUntil = now + 60000;
					record.Wrong = 0;
				}
				return 1;
			}
		}

		private static string NormalizeKey(string key)
		{
			if (string.IsNullOrEmpty(key))
			{
				return "";
			}
			StringBuilder stringBuilder = new StringBuilder(key.Length);
			for (int i = 0; i < key.Length; i++)
			{
				char c = char.ToUpperInvariant(key[i]);
				if (c == 'O')
				{
					c = '0';
				}
				else if (c == 'I' || c == 'L')
				{
					c = '1';
				}
				if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z'))
				{
					stringBuilder.Append(c);
				}
			}
			return stringBuilder.ToString();
		}

		private static Record RecordFor(string address)
		{
			if (!_records.TryGetValue(address, out var value))
			{
				if (_records.Count >= 256)
				{
					_records.Clear();
				}
				value = new Record();
				_records[address] = value;
			}
			return value;
		}

		internal static int Claim(string address)
		{
			lock (Gate)
			{
				long now = Now;
				if (_controller != null && _controller.Address == address)
				{
					_controller.LastBeat = now;
					return 1;
				}
				if (_controller != null)
				{
					return 2;
				}
				_controller = new Controller
				{
					Address = address,
					LastBeat = now
				};
				return 0;
			}
		}

		internal static void Beat(string address)
		{
			lock (Gate)
			{
				if (_controller != null && _controller.Address == address)
				{
					_controller.LastBeat = Now;
				}
			}
		}

		internal static bool Holds(string address)
		{
			lock (Gate)
			{
				return _controller != null && _controller.Address == address;
			}
		}

		internal static void Drop()
		{
			lock (Gate)
			{
				_controller = null;
			}
		}

		internal static void DropIf(string address)
		{
			lock (Gate)
			{
				if (_controller != null && _controller.Address == address)
				{
					_controller = null;
				}
			}
		}

		internal static bool Expired(long leaseMillis)
		{
			lock (Gate)
			{
				return _controller != null && Now - _controller.LastBeat > leaseMillis;
			}
		}
	}

	internal static class Cm2Bridge
	{
		private const string Cm2AssemblyName = "SFM_custom_mission_v2";

		internal const string UrlFunction = "PhoneRemote_Url";

		internal const string HostFunction = "PhoneRemote_Host";

		internal const string PortFunction = "PhoneRemote_Port";

		internal const string CodeFunction = "PhoneRemote_Code";

		internal const string BeatFunction = "PhoneRemote_Heartbeat";

		// OWNERSHIP, ASKED OUT LOUD (v2.0.4): scripts can now ask whether the
		// paired phone is actually in charge before they write a toy. Missions
		// that respect it stop fighting the phone for the piston or the
		// vibrator, and it is false the moment the phone goes quiet, so they
		// simply carry on.
		internal const string OwnsFunction = "PhoneRemote_Owns";

		private static ConstructorInfo _valueFromString;

		private static ConstructorInfo _valueFromBool;

		private static MethodInfo _registerFunction;

		internal static bool Available { get; private set; }

		internal static void Register()
		{
			Assembly assembly = null;
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			foreach (Assembly assembly2 in assemblies)
			{
				if (string.Equals(assembly2.GetName().Name, "SFM_custom_mission_v2", StringComparison.Ordinal))
				{
					assembly = assembly2;
					break;
				}
			}
			if (assembly == null)
			{
				AnnounceFallback("Custom Missions 2 is not loaded; the config switch General.Enabled drives the server instead.");
				return;
			}
			try
			{
				Type type = assembly.GetType("SFM_custom_mission_v2.Script.Engine");
				Type type2 = assembly.GetType("SFM_custom_mission_v2.Script.ProgramValue");
				if (type == null || type2 == null)
				{
					AnnounceFallback("Custom Missions 2's script types were not found; the config switch General.Enabled drives the server instead.");
					return;
				}
				_valueFromString = type2.GetConstructor(new Type[1] { typeof(string) });
				_valueFromBool = type2.GetConstructor(new Type[1] { typeof(bool) });
				MethodInfo[] methods = type.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				foreach (MethodInfo methodInfo in methods)
				{
					if (string.Equals(methodInfo.Name, "RegisterFunction", StringComparison.Ordinal))
					{
						ParameterInfo[] parameters = methodInfo.GetParameters();
						if (parameters.Length == 2 && parameters[0].ParameterType == typeof(string) && parameters[1].ParameterType.IsSubclassOf(typeof(MulticastDelegate)))
						{
							_registerFunction = methodInfo;
							break;
						}
					}
				}
				if (_registerFunction == null || _valueFromString == null || _valueFromBool == null)
				{
					AnnounceFallback("Custom Missions 2's Engine.RegisterFunction was not found in the expected shape; the config switch General.Enabled drives the server instead.");
					return;
				}
				RegisterOne("PhoneRemote_Url");
				RegisterOne("PhoneRemote_Host");
				RegisterOne("PhoneRemote_Port");
				RegisterOne("PhoneRemote_Code");
				RegisterOne("PhoneRemote_Heartbeat");
				RegisterOne("PhoneRemote_Owns");
				Available = true;
				ManualLogSource log = _log;
				if (log != null)
				{
					log.LogInfo((object)("Custom Missions 2 bridge registered: PhoneRemote_Url, PhoneRemote_Host, PhoneRemote_Port, PhoneRemote_Code, PhoneRemote_Heartbeat; url now = " + Server.Url));
				}
			}
			catch (Exception ex)
			{
				AnnounceFallback("Custom Missions 2 bridge failed (" + ex.Message + "); the config switch General.Enabled drives the server instead.");
			}
		}

		private static void RegisterOne(string name)
		{
			Type parameterType = _registerFunction.GetParameters()[1].ParameterType;
			MethodInfo method = parameterType.GetMethod("Invoke");
			ParameterInfo[] parameters = method.GetParameters();
			MethodInfo method2 = typeof(Cm2Bridge).GetMethod("ShimBody", BindingFlags.Static | BindingFlags.NonPublic);
			ParameterExpression parameterExpression = Expression.Parameter(parameters[0].ParameterType, "vars");
			ParameterExpression parameterExpression2 = Expression.Parameter(parameters[1].ParameterType, "thread");
			Expression body = Expression.Convert(Expression.Call(method2, Expression.Constant(name), Expression.Convert(parameterExpression, typeof(object)), Expression.Convert(parameterExpression2, typeof(object))), method.ReturnType);
			Delegate @delegate = Expression.Lambda(parameterType, body, parameterExpression, parameterExpression2).Compile();
			_registerFunction.Invoke(null, new object[2] { name, @delegate });
		}

		private static object ShimBody(string name, object variables, object thread)
		{
			try
			{
				// PER-FRAME FUNCTIONS ARE NOT LOGGED (v2.0.5): Owns is asked
				// every frame by a mission that is deciding whether to drive
				// a toy, and Heartbeat answers a timer. Logging those turned
				// the log into a wall of "script call: PhoneRemote_Owns",
				// which is how a working handback looked like a bug.
				if (!string.Equals(name, OwnsFunction, StringComparison.Ordinal) && !string.Equals(name, BeatFunction, StringComparison.Ordinal))
				{
					ManualLogSource log = _log;
					if (log != null)
					{
						log.LogInfo((object)("script call: " + name));
					}
				}
				object obj = null;
				switch (name)
				{
				case "PhoneRemote_Url":
					obj = Server.Url;
					break;
				case "PhoneRemote_Host":
					obj = "http://" + Server.Address;
					break;
				case "PhoneRemote_Port":
					obj = ":" + Server.Port + "/";
					break;
				case "PhoneRemote_Code":
					obj = Pairing.Display;
					break;
				case "PhoneRemote_Heartbeat":
					MissionBeat = Environment.TickCount64;
					obj = true;
					break;
				case "PhoneRemote_Owns":
					obj = _leaseHeld;
					break;
				default:
				{
					ManualLogSource log2 = _log;
					if (log2 != null)
					{
						log2.LogWarning((object)("script called an unknown Phone Remote function: " + name));
					}
					break;
				}
				}
				if (obj is string)
				{
					return _valueFromString.Invoke(new object[1] { obj });
				}
				if (obj is bool)
				{
					return _valueFromBool.Invoke(new object[1] { obj });
				}
				return _valueFromString.Invoke(new object[1] { "" });
			}
			catch (Exception ex)
			{
				ManualLogSource log3 = _log;
				if (log3 != null)
				{
					log3.LogWarning((object)("Phone Remote script call " + name + " failed: " + ex.Message));
				}
				return _valueFromString.Invoke(new object[1] { "" });
			}
		}

		private static void AnnounceFallback(string message)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Phone Remote: " + message));
			}
		}
	}

	internal static readonly object Gate = new object();

	internal static Plugin Instance;

	private static ManualLogSource _log;

	private static ConfigEntry<int> _port;

	private static ConfigEntry<float> _leaseSeconds;

	private static ConfigEntry<bool> _arousalEnabled;

	private static ConfigEntry<float> _arousalGain;

	private static ConfigEntry<bool> _enabled;

	private static ConfigEntry<bool> _requireMission;

		private static ConfigEntry<float> _audioLowFloor;

		private static ConfigEntry<float> _audioHighFloor;

		private static ConfigEntry<float> _audioFade;

	private static RemoteState _state = new RemoteState();

	private static DateTime _lastHeartbeatUtc;

	private static DateTime _vibeStartedUtc;

	private static DateTime _pistonStartedUtc;

	private static DateTime _lastArousalTickUtc;

	private static int _lastAppliedVibratorMode = -1;

	private static int _lastAppliedPistonLevel = -1;

	private static DateTime _lastPistonChangeUtc = DateTime.MinValue;

	private static string _lastLoggedControlState = "";

	private static PropertyInfo _randomProperty;

	private static FieldInfo _randomField;

	private static bool _randomTimerHeld;

	private static bool _randomMissed;

	private static bool _phoneQuietNoted;

	private static bool _gateClosedWhileConnected;

	private static DateTime _lastDriftLogUtc;

	internal static long MissionBeat;

	private static long _bridgeRetryAt;

	private static int _bridgeRetries;

	private static bool _leaseDropped;

	private static bool _leaseHeld;

	private static float _nextCardCheck;

	// PISTON PRIORITY (v2.0.1): while the phone holds the lease it owns the
	// piston - any other writer (missions, the game's own remote, the sex
	// scenes) gets its Apply() rewritten to the phone's level instead of
	// fighting the phone between frames. Off returns control to the game.
	private static ConfigEntry<bool> _phoneOwnsPiston;

	private static ConfigEntry<bool> _ownWhileQuiet;

	private static bool _phoneWritingPiston;

	private static DateTime _lastPistonDriftLogUtc = DateTime.MinValue;

	private static bool _cardActive;

	public override void Load()
	{
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Expected O, but got Unknown
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0189: Expected O, but got Unknown
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Expected O, but got Unknown
		Instance = this;
		_log = ((BasePlugin)this).Log;
		_port = ((BasePlugin)this).Config.Bind<int>("Web", "Port", 8765, "LAN port for the phone control page.");
		_leaseSeconds = ((BasePlugin)this).Config.Bind<float>("Web", "LeaseSeconds", 3f, "Seconds without a heartbeat before the paired phone counts as quiet. Quiet never stops the toys - they hold their last level; they stop on STOP, Logout, or when the card is switched off.");
		_arousalEnabled = ((BasePlugin)this).Config.Bind<bool>("Arousal", "Enabled", true, "Raise the game's ecstasy meter from phone-controlled stimulation.");
		_arousalGain = ((BasePlugin)this).Config.Bind<float>("Arousal", "GainPerSecondAtFullIntensity", 0.05f, "Ecstasy gained per second at 100 percent stimulation.");
		_enabled = ((BasePlugin)this).Config.Bind<bool>("General", "Enabled", true, "Master switch. Used directly only when Custom Missions 2 is not present; with CM2 the phone-settings card is the switch.");
		_requireMission = ((BasePlugin)this).Config.Bind<bool>("Web", "RequireMissionHeartbeat", true, "With Custom Missions 2 present, only answer while the Phone Toy Remote card is on in the game phone's settings.");
		_audioLowFloor = ((BasePlugin)this).Config.Bind<float>("Audio", "LowBandFloor", 0.25f, "Volume of the game's LOW vibrator loop at 1 percent strength; it rises smoothly to 1.0 at 50.");
		_audioHighFloor = ((BasePlugin)this).Config.Bind<float>("Audio", "HighBandFloor", 0.75f, "Volume of the game's HIGH vibrator loop at 51 percent strength; it rises smoothly to 1.0 at 100. Set 1.0 if 51 should be as loud as 50.");
		_audioFade = ((BasePlugin)this).Config.Bind<float>("Audio", "FadeSeconds", 0.22f, "How long the vibrator volume takes to reach a new strength. Smooths the 50/51 band change, pattern gaps and STOP so nothing clicks.");
		_phoneOwnsPiston = ((BasePlugin)this).Config.Bind<bool>("General", "PhoneOwnsPiston", true, "While the phone is connected it owns the piston: writes from the game, missions or the in-game remote are re-aimed at the phone's level instead of fighting it between frames. The piston is back in the game's hands the moment the phone lets go (STOP, Logout, card off, or - since v2.0.3 - the phone going quiet).");
		_ownWhileQuiet = ((BasePlugin)this).Config.Bind<bool>("General", "OwnWhileQuiet", false, "Off (default since v2.0.3): the phone owns the toys only while it is actually answering - close the browser or let the phone sleep and hunters, missions and the aftermath get the toys back within LeaseSeconds. On: the phone keeps owning its last level through silence, the way v2.0.0 did (the toys then stay at that level and nothing else can change them until STOP, Logout or the card is switched off).");
		try
		{
			Server.Start(PickAddress(), Math.Clamp(_port.Value, 1024, 65535));
			new Harmony("phone.toy.remote").Patch((MethodBase)AccessTools.Method(typeof(PlayerController), "OnUpdate", (Type[])null, (Type[])null), (HarmonyMethod)null, new HarmonyMethod(AccessTools.Method(typeof(Plugin), "Tick", (Type[])null, (Type[])null)), (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null);
			new Harmony("phone.toy.remote.piston").Patch((MethodBase)AccessTools.Method(typeof(PistonMachineController), "Apply", (Type[])null, (Type[])null), new HarmonyMethod(AccessTools.Method(typeof(Plugin), "PistonApplyPrefix", (Type[])null, (Type[])null)), (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null);
			new Harmony("phone.toy.remote.dynamic").Patch((MethodBase)AccessTools.Method(typeof(CommonVibratorController), "Update", (Type[])null, (Type[])null), (HarmonyMethod)null, new HarmonyMethod(AccessTools.Method(typeof(Plugin), "UpdateVibratorOutput", (Type[])null, (Type[])null)), (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null);
			new Harmony("phone.toy.remote.quiet").Patch((MethodBase)AccessTools.Method(typeof(CommonVibratorController), "AddMessage", (Type[])null, (Type[])null), new HarmonyMethod(AccessTools.Method(typeof(Plugin), "SuppressVibratorAnnouncement", (Type[])null, (Type[])null)), (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null);
			Pairing.NewCode();
			Cm2Bridge.Register();
			TryHookQuit();
			_log.LogInfo((object)("Phone Toy Remote listening on " + Server.Url + " - switch it on in the game phone's settings, then open the address and the pairing code there on your phone."));
		}
		catch (Exception ex)
		{
			_log.LogError((object)("Phone Toy Remote could not start: " + ex.Message));
		}
	}

	private static string PickAddress()
	{
		try
		{
			IPAddress[] hostAddresses = Dns.GetHostAddresses(Dns.GetHostName());
			foreach (IPAddress iPAddress in hostAddresses)
			{
				if (iPAddress.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(iPAddress) && IsAllowedCaller(iPAddress.ToString()))
				{
					return iPAddress.ToString();
				}
			}
		}
		catch (Exception ex)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Could not pick a LAN address, falling back to loopback: " + ex.Message));
			}
		}
		return "127.0.0.1";
	}

	internal static bool IsAllowedCaller(string address)
	{
		if (address == "127.0.0.1" || address == "::1")
		{
			return true;
		}
		if (IPAddress.TryParse(address, out IPAddress address2) && address2.AddressFamily == AddressFamily.InterNetwork)
		{
			byte[] addressBytes = address2.GetAddressBytes();
			if (addressBytes[0] == 10)
			{
				return true;
			}
			if (addressBytes[0] == 172 && addressBytes[1] >= 16 && addressBytes[1] <= 31)
			{
				return true;
			}
			if (addressBytes[0] == 192 && addressBytes[1] == 168)
			{
				return true;
			}
			if (addressBytes[0] == 169 && addressBytes[1] == 254)
			{
				return true;
			}
		}
		return false;
	}

	public static string CurrentUrl()
	{
		return Server.Url;
	}

	[HarmonyPriority(0)]
	private static void Tick()
	{
		try
		{
			// DEFERRED BRIDGE (v2.0.1): if the CM2 assembly was not on the
			// system yet when Load() ran, retry the bridge here every 5s for
			// the first minute, so the phone-settings card keeps working no
			// matter what order the plugins load in.
			if (!Cm2Bridge.Available && _bridgeRetries < 12 && Environment.TickCount64 >= _bridgeRetryAt)
			{
				_bridgeRetries++;
				_bridgeRetryAt = Environment.TickCount64 + 5000;
				Cm2Bridge.Register();
			}
			if (_gateClosedWhileConnected)
			{
				_gateClosedWhileConnected = false;
				bool flag = false;
				lock (Gate)
				{
					if (_state.Connected)
					{
						_state = new RemoteState();
						_lastHeartbeatUtc = DateTime.MinValue;
						flag = true;
					}
				}
				if (flag)
				{
					StopAllToys();
					_leaseDropped = false;
					LogReleased();
					ManualLogSource log = _log;
					if (log != null)
					{
						log.LogInfo((object)"Phone Remote: the card was switched off, so the toys were stopped.");
					}
				}
			}
			bool quiet;
			RemoteState remoteState;
			lock (Gate)
			{
				quiet = _state.Connected && (DateTime.UtcNow - _lastHeartbeatUtc).TotalSeconds > (double)Math.Max(2f, _leaseSeconds.Value);
				if (quiet && !_phoneQuietNoted)
				{
					_phoneQuietNoted = true;
					ManualLogSource log2 = _log;
					if (log2 != null)
					{
						log2.LogInfo((object)(_ownWhileQuiet.Value ? "The paired phone went quiet; the toys are held at their last level until it comes back, or you press STOP or Logout." : "The paired phone went quiet, so the toys are back in the game's hands - hunters and missions drive them again, and the phone takes over the moment it sends anything."));
					}
				}
				else if (!quiet)
				{
					_phoneQuietNoted = false;
				}
				remoteState = _state.Clone();
			}
			if (!remoteState.Connected)
			{
				_leaseHeld = false;
				if (_leaseDropped)
				{
					StopAllToys();
					_leaseDropped = false;
					LogReleased();
				}
				_lastArousalTickUtc = DateTime.MinValue;
				return;
			}
			if (quiet && !_ownWhileQuiet.Value)
			{
				// PHONE QUIET = RELEASE (v2.0.3): owning the toys through
				// silence is what kept hunters and the aftermath out - the
				// phone held its level forever and every SetPiston or
				// SetVibrator from the game was written over. Off the leash
				// the moment the page stops answering: the game drives
				// again, and the first thing the phone sends takes over.
				if (_leaseHeld)
				{
					_leaseHeld = false;
					HoldRandomTimer(hold: false);
					ManualLogSource logQuiet = _log;
					if (logQuiet != null)
					{
						logQuiet.LogInfo((object)"Phone Remote: released (the phone went quiet) - the game, hunters and missions own the toys again.");
					}
				}
				_lastArousalTickUtc = DateTime.MinValue;
				return;
			}
			_leaseHeld = true;
			GameStateData gameStateData = GameState.GameStateData;
			if (gameStateData != null)
			{
				double elapsed = ElapsedFor(remoteState, vibrator: true);
				double elapsed2 = ElapsedFor(remoteState, vibrator: false);
				int num = (remoteState.VibratorOn ? PatternPercent(remoteState.VibratorPattern, remoteState.VibratorIntensity, elapsed) : 0);
				int level = VibrationLevelHysteresis(num);
				int level2 = (remoteState.PistonOn ? PatternLevel(remoteState.PistonPattern, remoteState.PistonIntensity, vibrator: false, elapsed2) : 0);
				ApplyArousal(gameStateData, num);
				ApplyVibrator(gameStateData, level, leaseActive: true);
				ApplyPiston(level2);
				HoldRandomTimer(hold: true);
			}
		}
		catch (Exception ex)
		{
			ManualLogSource log3 = _log;
			if (log3 != null)
			{
				log3.LogWarning((object)("Phone Toy Remote update failed: " + ex.Message));
			}
		}
	}

	internal static int VibrationLevelHysteresis(int percent)
	{
		// Dragging fast past 50 used to flip the game between its low and high loops many
		// times a second, and each flip restarted a clip - that is the popping. Stay in the
		// band we are already in until the strength is clearly on the other side.
		int num = Math.Clamp(percent, 0, 100);
		if (num <= 0)
		{
			return 0;
		}
		if (num <= 50)
		{
			if (_lastAppliedVibratorMode == 2 && num > 47)
			{
				return 2;
			}
			return 1;
		}
		if (_lastAppliedVibratorMode == 1 && num < 54)
		{
			return 1;
		}
		return 2;
	}

	internal static int VibrationLevel(int percent, string pattern)
	{
		int num = Math.Clamp(percent, 0, 100);
		if (num <= 0)
		{
			return 0;
		}
		if (num <= 50)
		{
			return 1;
		}
		return 2;
	}

	private static void UpdateVibratorOutput()
	{
		try
		{
			RemoteState remoteState;
			lock (Gate)
			{
				remoteState = _state.Clone();
			}
			if (remoteState.Connected)
			{
				int num2 = (remoteState.VibratorOn ? PatternPercent(remoteState.VibratorPattern, remoteState.VibratorIntensity, ElapsedFor(remoteState, vibrator: true)) : 0);
				SetVibratorAudio(num2);
			}
		}
		catch (Exception ex)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Dynamic vibrator output failed: " + ex.Message));
			}
		}
	}

	private static float _vibeLowGain;
	private static float _vibeHighGain;
	private static DateTime _vibeAudioUtc = DateTime.MinValue;

	private static void SetVibratorAudio(int percent)
	{
		// 0% is silence. 1-50% rides the game's low loop, 51-100% its high loop, and the
		// gain tracks the strength inside each band instead of slamming between 0 and 1.
		// Both bands are faded over ~0.22s so crossing 50 <-> 51 (and STOP, and the
		// Tease/Pulse gaps) never clicks.
		int num = Math.Clamp(percent, 0, 100);
		float num2 = 0f;
		float num3 = 0f;
		if (num > 0)
		{
			int num8 = VibrationLevelHysteresis(num);
			if (num8 == 1)
			{
				float num6 = Math.Clamp(_audioLowFloor.Value, 0f, 1f);
				float num9 = Math.Min(1f, Math.Max(0f, (float)(num - 1) / 49f));
				num2 = num6 + (1f - num6) * num9;
			}
			else
			{
				float num7 = Math.Clamp(_audioHighFloor.Value, 0f, 1f);
				float num10 = Math.Min(1f, Math.Max(0f, (float)(num - 51) / 49f));
				num3 = num7 + (1f - num7) * num10;
			}
		}
		DateTime utcNow = DateTime.UtcNow;
		float num4 = ((_vibeAudioUtc == DateTime.MinValue) ? 0.016f : (float)Math.Clamp((utcNow - _vibeAudioUtc).TotalSeconds, 0.0, 0.25));
		_vibeAudioUtc = utcNow;
		float num11 = Math.Abs(num2 - _vibeLowGain) + Math.Abs(num3 - _vibeHighGain);
		float num12 = Math.Min(0.6f, Math.Max(0.02f, _audioFade.Value) * (1f + 1.5f * num11));
		float num5 = Math.Min(1f, num4 / num12);
		_vibeLowGain += (num2 - _vibeLowGain) * num5;
		_vibeHighGain += (num3 - _vibeHighGain) * num5;
		if (_vibeLowGain < 0.001f)
		{
			_vibeLowGain = 0f;
		}
		if (_vibeHighGain < 0.001f)
		{
			_vibeHighGain = 0f;
		}
		CommonVibratorController leader = CommonVibratorController.Leader;
		if (!((Object)(object)leader == (Object)null))
		{
			SetSmoothVolume(leader.lowVolume, _vibeLowGain);
			SetSmoothVolume(leader.highVolume, _vibeHighGain);
			SetSourceVolume(leader.lowAudioSource, _vibeLowGain);
			SetSourceVolume(leader.highAudioSource, _vibeHighGain);
		}
	}

	private static void SetSmoothVolume(SmoothFloat smooth, float volume)
	{
		if (smooth != null)
		{
			float current = (smooth.Target = Math.Clamp(volume, 0f, 1f));
			smooth.Current = current;
		}
	}

	private static void SetSourceVolume(AudioSource source, float volume)
	{
		if ((Object)(object)source != (Object)null)
		{
			source.volume = Math.Clamp(volume, 0f, 1f);
		}
	}

	private static bool SuppressVibratorAnnouncement()
	{
		return _leaseHeld;
	}

	private static void ApplyVibrator(GameStateData game, int level, bool leaseActive)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Invalid comparison between Unknown and I4
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Invalid comparison between Unknown and I4
		try
		{
			VibrationModeType playerVibrationModeType = game.PlayerVibrationModeType;
			if (leaseActive && level == _lastAppliedVibratorMode && (int)playerVibrationModeType == level)
			{
				return;
			}
			if (leaseActive && (int)playerVibrationModeType != level && level == _lastAppliedVibratorMode && (DateTime.UtcNow - _lastDriftLogUtc).TotalSeconds > 2.0)
			{
				_lastDriftLogUtc = DateTime.UtcNow;
				ManualLogSource log = _log;
				if (log != null)
				{
					log.LogInfo((object)("Vibrator drift: game=" + playerVibrationModeType.ToString() + " phone=" + level + "; the phone's level is re-asserted."));
				}
			}
			game.PlayerVibrationModeType = (VibrationModeType)level;
			_lastAppliedVibratorMode = (leaseActive ? level : (-1));
			HoldRandomTimer(leaseActive);
		}
		catch (Exception ex)
		{
			ManualLogSource log2 = _log;
			if (log2 != null)
			{
				log2.LogWarning((object)("Vibrator mode apply failed: " + ex.Message));
			}
		}
	}

	private static void HoldRandomTimer(bool hold)
	{
		if (_randomProperty == null && _randomField == null && !_randomMissed)
		{
			_randomProperty = typeof(CommonVibratorController).GetProperty("changeRemainTime", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (_randomProperty == null)
			{
				_randomField = typeof(CommonVibratorController).GetField("changeRemainTime", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			}
			if (_randomProperty == null && _randomField == null)
			{
				_randomMissed = true;
				ManualLogSource log = _log;
				if (log != null)
				{
					log.LogWarning((object)"Phone Toy Remote could not find the vibrator's changeRemainTime member; the game may switch the toy on and off by itself.");
				}
			}
		}
		if (_randomProperty == null && _randomField == null)
		{
			return;
		}
		try
		{
			if (hold)
			{
				if (ReadRandomTimer() < 3000f)
				{
					WriteRandomTimer(3600f);
					_randomTimerHeld = true;
				}
			}
			else if (_randomTimerHeld)
			{
				WriteRandomTimer(5f);
				_randomTimerHeld = false;
			}
		}
		catch (Exception ex)
		{
			ManualLogSource log2 = _log;
			if (log2 != null)
			{
				log2.LogWarning((object)("Could not hold vibrator timer; other modes may override: " + ex.Message));
			}
		}
	}

	private static float ReadRandomTimer()
	{
		object value;
		if (_randomProperty != null)
		{
			value = _randomProperty.GetValue(null);
		}
		else
		{
			if (!(_randomField != null))
			{
				return float.PositiveInfinity;
			}
			value = _randomField.GetValue(null);
		}
		if (value is IConvertible)
		{
			return Convert.ToSingle(value);
		}
		return float.PositiveInfinity;
	}

	private static void WriteRandomTimer(float value)
	{
		if (_randomProperty != null)
		{
			_randomProperty.SetValue(null, value);
		}
		else if (_randomField != null)
		{
			_randomField.SetValue(null, value);
		}
	}

	private static void ApplyPiston(int level)
	{
		if (level == _lastAppliedPistonLevel || (_lastAppliedPistonLevel > 0 && level > 0 && (DateTime.UtcNow - _lastPistonChangeUtc).TotalMilliseconds < 600.0))
		{
			return;
		}
		try
		{
			GameStateData gameStateData = GameState.GameStateData;
			if (gameStateData != null)
			{
				gameStateData.PistonMachineModeType = Math.Clamp(level, 0, 4);
			}
			PlayerController instance = PlayerController.Instance;
			if (!((Object)(object)instance == (Object)null))
			{
				PlayerClassAccessor pca = instance.pca;
				PistonMachineController val = ((pca != null) ? pca.PistonMachineController : null);
				if (val != null)
				{
					_phoneWritingPiston = true;
					try
					{
						val.CurrentSpeedType = Math.Clamp(level, 0, 3);
						val.Apply();
					}
					finally
					{
						_phoneWritingPiston = false;
					}
				}
				_lastAppliedPistonLevel = level;
				_lastPistonChangeUtc = DateTime.UtcNow;
			}
		}
		catch (Exception)
		{
		}
	}

	// PISTON PRIORITY (v2.0.1): every piston write in the game funnels
	// through PistonMachineController.Apply() - the missions' SetPiston,
	// the in-game remote, ToyRemoteAscension, the sex scenes, all of them.
	// While the phone holds the lease, this prefix re-aims every foreign
	// write at the phone's own level before it is applied, so nobody
	// fights the phone between frames any more. The phone's own writes
	// (flagged) and every write once the lease is gone pass untouched.
	private static void PistonApplyPrefix(PistonMachineController __instance)
	{
		try
		{
			if (!_phoneOwnsPiston.Value || !_leaseHeld || _phoneWritingPiston || (Object)(object)__instance == (Object)null)
			{
				return;
			}
			RemoteState remoteState;
			lock (Gate)
			{
				remoteState = _state.Clone();
			}
			if (!remoteState.Connected)
			{
				return;
			}
			int num = Math.Clamp(remoteState.PistonOn ? PatternLevel(remoteState.PistonPattern, remoteState.PistonIntensity, vibrator: false, ElapsedFor(remoteState, vibrator: false)) : 0, 0, 3);
			GameStateData gameStateData = GameState.GameStateData;
			if (gameStateData != null)
			{
				gameStateData.PistonMachineModeType = num;
			}
			if ((int)__instance.CurrentSpeedType != num)
			{
				if ((DateTime.UtcNow - _lastPistonDriftLogUtc).TotalSeconds > 2.0)
				{
					_lastPistonDriftLogUtc = DateTime.UtcNow;
					ManualLogSource log = _log;
					if (log != null)
					{
						log.LogInfo((object)("Piston drift: game=" + (int)__instance.CurrentSpeedType + " phone=" + num + "; the phone's level is re-asserted."));
					}
				}
				__instance.CurrentSpeedType = num;
			}
		}
		catch (Exception)
		{
		}
	}

	private static void StopAllToys()
	{
		_vibeAudioUtc = DateTime.MinValue;
		_lastAppliedVibratorMode = -1;
		_lastAppliedPistonLevel = -1;
		_lastPistonChangeUtc = DateTime.MinValue;
		try
		{
			SetVibratorAudio(0);
			GameStateData gameStateData = GameState.GameStateData;
			if (gameStateData != null)
			{
				ApplyVibrator(gameStateData, 0, leaseActive: false);
				gameStateData.PistonMachineModeType = 0;
			}
			PlayerController instance = PlayerController.Instance;
			object obj;
			if (!((Object)(object)instance == (Object)null))
			{
				PlayerClassAccessor pca = instance.pca;
				obj = ((pca != null) ? pca.PistonMachineController : null);
			}
			else
			{
				obj = null;
			}
			PistonMachineController val = (PistonMachineController)obj;
			if (val != null)
			{
				val.CurrentSpeedType = 0;
				val.Apply();
			}
		}
		catch (Exception ex)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Phone Toy Remote shutdown failed: " + ex.Message));
			}
		}
	}

	private static void ApplyArousal(GameStateData game, int vibratorPercent)
	{
		if (!_arousalEnabled.Value)
		{
			return;
		}
		if (_lastArousalTickUtc == DateTime.MinValue)
		{
			_lastArousalTickUtc = DateTime.UtcNow;
			return;
		}
		DateTime utcNow = DateTime.UtcNow;
		float num = (float)Math.Clamp((utcNow - _lastArousalTickUtc).TotalSeconds, 0.0, 0.25);
		_lastArousalTickUtc = utcNow;
		if (vibratorPercent > 0 && num > 0f)
		{
			float num2 = Math.Max(0f, _arousalGain.Value) * ((float)Math.Clamp(vibratorPercent, 0, 100) / 100f) * num;
			game.PlayerEcstasy = Math.Clamp(game.PlayerEcstasy + num2, 0f, 1f);
		}
	}

	private static double ElapsedFor(RemoteState state, bool vibrator)
	{
		DateTime dateTime = ((vibrator || state.Sync) ? _vibeStartedUtc : _pistonStartedUtc);
		if (dateTime == default(DateTime))
		{
			return 0.0;
		}
		double num = (DateTime.UtcNow - dateTime).TotalSeconds;
		return (num < 0.0) ? 0.0 : num;
	}

	private static int PatternLevel(string pattern, int intensity, bool vibrator, double elapsed)
	{
		int percent = PatternPercent(pattern, intensity, elapsed);
		if (vibrator)
		{
			return VibrationLevel(percent, pattern);
		}
		return ToPistonLevel(percent);
	}

	private static int PatternPercent(string pattern, int intensity, double elapsed)
	{
		int num = Math.Clamp(intensity, 0, 100);
		float num2 = (float)elapsed;
		switch (pattern)
		{
		case "Pulse":
			if (!(num2 % 1f < 0.4f))
			{
				return 0;
			}
			return num;
		case "Wave":
			return (int)((double)num * (0.20000000298023224 + 0.800000011920929 * (0.5 + 0.5 * Math.Sin((double)num2 * Math.PI * 2.0 / 8.0))));
		case "Tease":
		{
			float num3 = num2 % 20f;
			if (!(num3 < 12f))
			{
				return 0;
			}
			return (int)((float)num * Math.Min(1f, num3 / 8f));
		}
		default:
			return num;
		}
	}

	private static int ToPistonLevel(int percent)
	{
		if (percent <= 0)
		{
			return 0;
		}
		if (percent >= 34)
		{
			if (percent < 67)
			{
				return 2;
			}
			return 3;
		}
		return 1;
	}

	private static void LogControlState(RemoteState state)
	{
		string text = state.VibratorOn + ":" + state.VibratorIntensity + ":" + state.VibratorPattern + ":" + state.PistonOn + ":" + state.PistonIntensity + ":" + state.PistonPattern + ":" + state.Sync;
		if (!string.Equals(text, _lastLoggedControlState, StringComparison.Ordinal))
		{
			_lastLoggedControlState = text;
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogInfo((object)("Phone control: vibrator " + (state.VibratorOn ? "on" : "off") + " " + state.VibratorIntensity + "% " + state.VibratorPattern + "; piston " + (state.PistonOn ? "on" : "off") + " " + state.PistonIntensity + "% " + state.PistonPattern + "; sync " + state.Sync));
			}
		}
	}

	private static void LogReleased()
	{
		if (_lastLoggedControlState != "released")
		{
			_lastLoggedControlState = "released";
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogInfo((object)"Phone control: released - all toys stopped.");
			}
		}
	}

	private static void TryHookQuit()
	{
		try
		{
			Application.quitting += DelegateSupport.ConvertDelegate<Il2CppSystem.Action>((System.Action)delegate
			{
				Server.Shutdown();
			});
		}
		catch (Exception ex)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Could not hook the game's quit; the port still closes with the process: " + ex.Message));
			}
		}
		try
		{
			AppDomain.CurrentDomain.ProcessExit += delegate
			{
				Server.Shutdown();
			};
		}
		catch (Exception)
		{
		}
	}

	internal void LogPhone(string message)
	{
		ManualLogSource log = _log;
		if (log != null)
		{
			log.LogInfo((object)("Phone Remote: " + message));
		}
	}

	private static bool GateOpen()
	{
		bool flag = ((!Cm2Bridge.Available || !_requireMission.Value) ? _enabled.Value : MissionCardActive());
		if (!flag && _state.Connected)
		{
			_gateClosedWhileConnected = true;
		}
		return flag;
	}

	private static bool MissionCardActive()
	{
		float num = (float)DateTime.UtcNow.TimeOfDay.TotalSeconds;
		if (num < _nextCardCheck)
		{
			return _cardActive;
		}
		_nextCardCheck = num + 2f;
		try
		{
			string path = Path.Combine(Paths.PluginPath, "SFM_custom_mission_v2", "Save", "PhoneToyRemote", "save0.json");
			if (!File.Exists(path))
			{
				_cardActive = false;
				return false;
			}
			using StreamReader streamReader = File.OpenText(path);
			string text = streamReader.ReadToEnd();
			_cardActive = text.Contains("active") && text.Contains("true");
		}
		catch (Exception ex)
		{
			ManualLogSource log = _log;
			if (log != null)
			{
				log.LogWarning((object)("Could not read the Phone Toy Remote card state: " + ex.Message));
			}
			_cardActive = false;
		}
		return _cardActive;
	}
}

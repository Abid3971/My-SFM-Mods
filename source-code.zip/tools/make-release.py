#!/usr/bin/env python3
"""Build both zips: the drop-in release and the source archive.

Usage:
    python tools/make-release.py [path-to-game-install]

The game install is only used to fetch CustomMissions2/PhoneToyRemote/; the dll
comes from src/bin/Release.
"""
import hashlib
import pathlib
import sys
import zipfile

REPO = pathlib.Path(__file__).resolve().parent.parent
NAME, VER = "PhoneToyRemote", "v4"


def main():
    game = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else REPO.parent / "SecretFlasherManaka v1.1.3"
    dll = REPO / "src" / "bin" / "Release" / "PhoneToyRemote.dll"
    if not dll.exists():
        print("build first:  dotnet build src/PhoneToyRemote.csproj -c Release")
        return 1
    cm2 = game / "CustomMissions2" / "PhoneToyRemote"
    dist = REPO / "dist"
    dist.mkdir(exist_ok=True)
    sha = hashlib.sha256(dll.read_bytes()).hexdigest()

    rel = dist / (NAME + "-Release_" + VER + ".zip")
    with zipfile.ZipFile(rel, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("SHA256SUMS.txt", sha + "  BepInEx/plugins/PhoneToyRemote.dll\n")
        z.write(dll, "BepInEx/plugins/PhoneToyRemote.dll")
        for f in ("main.code", "meta.json"):
            p = cm2 / f
            if p.exists():
                z.write(p, "CustomMissions2/PhoneToyRemote/" + f)

    srcz = dist / (NAME + "-Source_" + VER + ".zip")
    with zipfile.ZipFile(srcz, "w", zipfile.ZIP_DEFLATED) as z:
        for f in ("README.md", "CHANGELOG.md"):
            z.write(REPO / f, f)
        for p in sorted((REPO / "src").rglob("*")):
            if p.is_file() and "bin" not in p.parts and "obj" not in p.parts:
                z.write(p, "src/" + p.relative_to(REPO / "src").as_posix())
        for p in sorted((REPO / "tests").glob("*")):
            if p.is_file():
                z.write(p, "tests/" + p.name)

    print("release:", rel.name, rel.stat().st_size, "bytes  (dll sha", sha[:12] + ")")
    print("source :", srcz.name, srcz.stat().st_size, "bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
